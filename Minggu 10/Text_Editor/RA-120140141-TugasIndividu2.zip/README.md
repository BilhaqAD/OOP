"""
Nama	: Bilhaq Avi Dewantara
NIM	    : 120140141
Kelas	: PBO RA
Prodi	: Teknik Informatika
"""

Berikut merupakan B.A.D TextEditor  yang telah saya buat dengan menggunakan modul tkinter.
TextEditor tersebut terintegrasi tombol New, Open, dan Save As dengan dipadukan scroll Bar.
Namun, pada scroll bar horizontal tidak bisa digunakan karena tidak tertampilkan tombol scroll tersebut.